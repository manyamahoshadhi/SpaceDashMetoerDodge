package com.example.spacedash

interface GameTask {
    //end game
    fun closeGame(mScore:Int)
}